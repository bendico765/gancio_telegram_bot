import aiohttp
import aiohttp_client_cache

__all__=["get_event_image"]


async def get_event_image(
        instance_url: str,
        image_name: str,
        cache: aiohttp_client_cache.backends = None
) -> dict:
    """
    Fetches the image of specified event.

    :param instance_url: str, the URL of the Gancio instance where the event is saved
    :param image_name: str, the name and file extension suffix of the image to fetch
    :param cache: aiohttp_client_cache.backends, optional the cache to use to save/fetch the http requests
    :return: dict

    :Example:
    >>> import asyncio
    >>> from gancioAPI import get_event_image
    >>> from aiohttp_client_cache import SQLiteBackend
    >>>
    >>> url = "https://gancio.cisti.org"
    >>> image_name = "072e0caedb51e352c43813376b59b26d.jpg"
    >>> cache = SQLiteBackend(
    ...     cache_name = "aio-requests.db"
    ... )
    >>>
    >>> res = asyncio.run(get_event_image(url, image_name, cache))
    """
    url = f"{instance_url}/media/thumb/{image_name}"

    if cache is None:
        session = aiohttp.ClientSession()
    else:
        session = aiohttp_client_cache.CachedSession(cache=cache)

    try:
        async with session.get(url) as response:
            return {
                "status": response.status,
                "content": await response.read()
            }
    finally:
        await session.close()