import aiohttp
import aiohttp_client_cache

__all__ = ["get_events"]


async def get_events(
        instance_url: str,
        params: dict = None,
        cache: aiohttp_client_cache.backends = None
) -> dict:
    """
    Fetches the events saved on the specified Gancio instance using the specified url parameters.
    Information about the available URL parameters can be found at https://gancio.org/dev/api

    :param instance_url: str, the URL of the Gancio instance where the event is saved
    :param params: dict, optional dictionary specifying for each URL parameter (key) its value (value)
    :param cache: aiohttp_client_cache.backends, optional the cache to use to save/fetch the http requests
    :return: dict

    :Example:
    >>> import asyncio
    >>> from gancioAPI import get_events
    >>> from aiohttp_client_cache import SQLiteBackend
    >>>
    >>> url = "https://gancio.cisti.org"
    >>> # for this example we want to fetch all the events
    >>> # starting from 1-1-1970 00:00:00
    >>> params = {"start": 0}
    >>> cache = SQLiteBackend(
    ...     cache_name = "aio-requests.db"
    ... )
    >>> result = asyncio.run(get_events(url, params, cache))
    """
    url = f"{instance_url}/api/events"

    if cache is None:
        session = aiohttp.ClientSession()
    else:
        session = aiohttp_client_cache.CachedSession(cache=cache)

    try:
        async with session.get(url, params=params) as response:
            return {
                "status": response.status,
                "json_content": await response.json()
            }
    finally:
        await session.close()
