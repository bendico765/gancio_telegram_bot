import aiohttp
import aiohttp_client_cache
from bs4 import BeautifulSoup

__all__ = ["get_event_description"]


async def get_event_description(
        instance_url: str,
        event_slug: str,
        cache: aiohttp_client_cache.backends = None
) -> dict:
    """
    Fetches the html description of an event using the event slug

    :param instance_url: str, the URL of the Gancio instance where the event is saved
    :param event_slug: str, the slug of the event to fetch
    :param cache: aiohttp_client_cache.backends, optional the cache to use to save/fetch the http requests
    :return: dict

    :Example:
    >>> import asyncio
    >>> from gancioAPI import get_event_description
    >>> from aiohttp_client_cache import SQLiteBackend
    >>>
    >>> url = "https://gancio.cisti.org"
    >>> event_slug = "jazz-in-jardino-2"
    >>> cache = SQLiteBackend(
    ...     cache_name = "aio-requests.db"
    ... )
    >>>
    >>> result = asyncio.run(get_event_description(url, event_slug, cache))
    """
    url = f"{instance_url}/event/{event_slug}"

    if cache is None:
        session = aiohttp.ClientSession()
    else:
        session = aiohttp_client_cache.CachedSession(cache=cache)

    try:
        async with session.get(url) as response:
            if response.status != 200:
                html_event_description = ""
            else:
                html_full_content = await response.text()

                html_soup = BeautifulSoup(html_full_content, "html.parser")

                classes = html_soup.findAll(class_="p-description text-body-1 pa-3 rounded")
                if classes == []:
                    html_event_description = ""
                else:
                    html_event_description = str(classes[0])

            return {
                "status": response.status,
                "html_content": html_event_description
            }
    finally:
        await session.close()