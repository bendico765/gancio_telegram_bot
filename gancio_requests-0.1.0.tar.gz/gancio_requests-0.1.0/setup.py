# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['gancio_requests', 'gancio_requests.requests']

package_data = \
{'': ['*']}

install_requires = \
['aiohttp-client-cache>=0.7.3,<0.8.0',
 'aiohttp>=3.8.1,<4.0.0',
 'beautifulsoup4>=4.11.1,<5.0.0']

setup_kwargs = {
    'name': 'gancio-requests',
    'version': '0.1.0',
    'description': 'Asynchronous functions for making HTTP requests to Gancio istances',
    'long_description': None,
    'author': 'bendico765',
    'author_email': 'bendico765@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
